package com.brillio.udemy.rest.webservices.restfulwebservices.exception;

public class ExceptionRespnse {
	
	private String mobileNumber;
	private String message;
	private String details;
	public ExceptionRespnse(String mobileNumber, String message, String details) {
		super();
		this.mobileNumber = mobileNumber;
		this.message = message;
		this.details = details;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public String getMessage() {
		return message;
	}
	public String getDetails() {
		return details;
	}

}
