package com.brillio.udemy.rest.webservices.restfulwebservices;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

//@SpringBootTest

@RunWith(SpringRunner.class)
class RestfulWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
 