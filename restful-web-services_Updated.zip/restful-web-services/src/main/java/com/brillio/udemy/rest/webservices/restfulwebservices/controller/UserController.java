package com.brillio.udemy.rest.webservices.restfulwebservices.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.brillio.udemy.rest.webservices.restfulwebservices.entity.User;
import com.brillio.udemy.rest.webservices.restfulwebservices.entity.UserNotFoundException;
import com.brillio.udemy.rest.webservices.restfulwebservices.repository.UserRepository;
import com.brillio.udemy.rest.webservices.restfulwebservices.service.UserService;



@RestController
public class UserController {

@Autowired
private UserService service;
	
	
// for H2 DB
@Autowired
private UserRepository userRepository;


@GetMapping("/jpa/users")
public List<User> retrieveAllUsers() {
	return userRepository.findAll();
}

@GetMapping("/jpa/users/{id}")
public User retrieveDetailsForUser(@PathVariable int id ) {
	return service.retrieveUser(id);
}

@DeleteMapping("/jpa/users/{id}")
public void deleteUser(@PathVariable int id) {
	 service.deleteUsers(id);
	
}

@PostMapping("/jpa/users")
public User createUser(@Valid @RequestBody User user) {
	User savedUser=service.createUser(user);
	 return savedUser;

}


}
