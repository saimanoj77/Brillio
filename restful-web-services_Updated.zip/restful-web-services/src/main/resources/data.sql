insert into user values(1001, '9866453379','Manoj');
insert into user values(1002, '9866653379','Charan');
insert into user values(1003, '9866353379','Satya');