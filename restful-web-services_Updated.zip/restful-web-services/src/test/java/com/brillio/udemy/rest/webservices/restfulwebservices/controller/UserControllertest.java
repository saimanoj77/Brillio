package com.brillio.udemy.rest.webservices.restfulwebservices.controller;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.brillio.udemy.rest.webservices.restfulwebservices.entity.User;





@ExtendWith(SpringExtension.class)
@WebMvcTest(value = UserController.class)


//@WithMockUser
public class UserControllertest{
	
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private UserController userController;

	User mockCourse = new User(1001, "Manoj", "9866453379");

	String exampleCourseJson = "{\"id\":1001,\"name\":\"Manoj\",\"mobileNumber\":\"9866453379\"}";

	@Test
	public void retrieveDetailsForCourse() throws Exception {
		
		
		Mockito.when(
				userController.retrieveDetailsForUser(Mockito.anyInt())).thenReturn(mockCourse);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/jpa/users/1001").accept(
				MediaType.APPLICATION_JSON);
		System.out.println("gani111"+requestBuilder);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{\"name\":"
				+ "\"Manoj\",\"mobileNumber\":\"9866453379\"}";
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}
	
	@Test
	public void createUser() throws Exception {

		Mockito.when(userController.createUser(Mockito.any(User.class))).thenReturn(mockCourse);

		RequestBuilder requestBuilder = MockMvcRequestBuilders
										.post("/jpa/users")
										.accept(MediaType.APPLICATION_JSON)
										.content(exampleCourseJson)
										.contentType(MediaType.APPLICATION_JSON);
		System.out.println("gani2221 "+requestBuilder.toString());
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println("manoj "+result.getResponse());
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	
	}
	
	@Test
	   public void testdeleteUser() throws Exception {
	      User Addr = getAddr();
	      doNothing().when(userController).deleteUser(1);
	      mockMvc.perform(delete("/jpa/users/1001/" + Addr.getId()).contentType(MediaType.APPLICATION_JSON))
	      .andExpect(status().isOk()).andReturn();
	   }

	
	@Test
	   public void testGetAllUsers() throws Exception {
	      User Addr = new User();
	      List<User> Addrs = new ArrayList<>();
	      Addrs.add(Addr);
	      given(userController.retrieveAllUsers()).willReturn(Addrs);
	      mockMvc.perform(get("/jpa/users/").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
	         .andExpect(jsonPath("$[0].name", is(Addr.getName())));
	   }
	 private User getAddr() {
	      User Addr = new User();
	      Addr.setId(1);
	      Addr.setName("Manoj");
	      Addr.setMobileNumber("9866453379");
	      return Addr;
	   }

	}


