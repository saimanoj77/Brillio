package com.brillio.udemy.rest.webservices.restfulwebservices.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.brillio.udemy.rest.webservices.restfulwebservices.RestfulWebServicesApplication;
import com.brillio.udemy.rest.webservices.restfulwebservices.entity.User;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = RestfulWebServicesApplication.class)
public class UserServicetest {
   @MockBean
   private UserService AddrService;
   @Test
   public void testGetAllAddrs() throws Exception {
      User Addr = getAddr();
      List<User> Addrs = new ArrayList<>();
      Addrs.add(Addr);
      given(AddrService.retrieveAllUsers()).willReturn(Addrs);
      List<User> result = AddrService.retrieveAllUsers();
      assertEquals(result.size(), 1);
   }
   @Test
   public void testGetAddr() throws Exception {
      User Addr = getAddr();
      given(AddrService.retrieveUser(1)).willReturn(Addr);
      User result = AddrService.retrieveUser(1);
      assertEquals(result.getId(), 1);	
   }
   @Test
   public void testDeleteAddr() throws Exception {
      doNothing().when(AddrService).deleteUsers(0);
      AddrService.deleteUsers(1);
      assertTrue(true);
   }
   
   private User getAddr() {
      User Addr = new User();
      Addr.setId(1);
      Addr.setName("Manoj");
      Addr.setMobileNumber("9866453379");
      return Addr;
   }
}
